﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class EditForm : Form
    {
        public Table[] tables = new Table[]
        {
            new Table()
            {
                Label = "Items",
                Name = "items",
                Inputs = new Input[]
                {
                    new Input()
                    {
                        Label = "Name",
                        Name = "name",
                        Type = InputType.VARCHAR
                    },
                    new Input()
                    {
                        Label = "Manufacturer",
                        Name = "manufacturer",
                        Type = InputType.VARCHAR
                    },
                    new Input()
                    {
                        Label = "Description",
                        Name = "description",
                        Type = InputType.TEXT
                    },
                    new Input()
                    {
                        Label = "Price",
                        Name = "price",
                        Type = InputType.DECIMAL
                    }
                }
            },
            new Table()
            {
                Label = "Stock",
                Name = "stock",
                Inputs = new Input[]
                {
                    new Input()
                    {
                        Label = "Amount",
                        Name = "amount",
                        Type = InputType.INT
                    },
                    new Input()
                    {
                        Label = "Item ID",
                        Name = "items_id",
                        Type = InputType.INT
                    }
                }
            },
            new Table()
            {
                Label = "Users",
                Name = "users",
                Inputs = new Input[]
                {
                    new Input()
                    {
                        Label = "Username",
                        Name = "username",
                        Type = InputType.VARCHAR
                    },
                    new Input()
                    {
                        Label = "Email",
                        Name = "email",
                        Type = InputType.VARCHAR
                    },
                    new Input()
                    {
                        Label = "Password",
                        Name = "password",
                        Type = InputType.VARCHAR
                    },
                    new Input()
                    {
                        Label = "Type",
                        Name = "type",
                        Type = InputType.INT
                    }
                }
            },
            new Table()
            {
                Label = "Reviews",
                Name = "reviews",
                Inputs = new Input[]
                {
                    new Input()
                    {
                        Label = "Rating",
                        Name = "rating",
                        Type = InputType.INT
                    },
                    new Input()
                    {
                        Label = "Title",
                        Name = "title",
                        Type = InputType.VARCHAR
                    },
                    new Input()
                    {
                        Label = "Description",
                        Name = "description",
                        Type = InputType.TEXT
                    },
                    new Input()
                    {
                        Label = "User ID",
                        Name = "user_id",
                        Type = InputType.INT
                    },
                    new Input()
                    {
                        Label = "Item ID",
                        Name = "item_id",
                        Type = InputType.INT
                    }
                }
            },
            new Table()
            {
                Label = "Item Specifications",
                Name = "item_specifications",
                Inputs = new Input[]
                {
                    new Input()
                    {
                        Label = "Name",
                        Name = "name",
                        Type = InputType.VARCHAR
                    },
                    new Input()
                    {
                        Label = "Value",
                        Name = "value",
                        Type = InputType.TEXT
                    },
                    new Input()
                    {
                        Label = "Item ID",
                        Name = "item_id",
                        Type = InputType.INT
                    }
                }
            },
            new Table()
            {
                Label = "Invoice Lines",
                Name = "invoice_lines",
                Inputs = new Input[]
                {
                    new Input()
                    {
                        Label = "Amount",
                        Name = "amount",
                        Type = InputType.INT
                    },
                    new Input()
                    {
                        Label = "Price",
                        Name = "price",
                        Type = InputType.DECIMAL
                    },
                    new Input()
                    {
                        Label = "Tax",
                        Name = "tax",
                        Type = InputType.CHAR
                    },
                    new Input()
                    {
                        Label = "Invoice ID",
                        Name = "invoice_id",
                        Type = InputType.INT
                    },
                    new Input()
                    {
                        Label = "Item ID",
                        Name = "item_id",
                        Type = InputType.INT
                    }
                }
            },
            new Table()
            {
                Label = "Sales",
                Name = "sales",
                Inputs = new Input[]
                {
                    new Input()
                    {
                        Label = "User ID",
                        Name = "user_id",
                        Type = InputType.INT
                    },
                    new Input()
                    {
                        Label = "Invoice ID",
                        Name = "invoice_id",
                        Type = InputType.INT
                    }
                }
            },
            new Table()
            {
                Label = "Sale Item",
                Name = "sale_item",
                Inputs = new Input[]
                {
                    new Input()
                    {
                        Label = "Item ID",
                        Name = "item_id",
                        Type = InputType.INT
                    },
                    new Input()
                    {
                        Label = "Sale ID",
                        Name = "sale_id",
                        Type = InputType.INT
                    }
                }
            }
        };

        public EditForm()
        {
            InitializeComponent();

            TableSelect.DataSource = tables;
            TableSelect.DisplayMember = "Label";
            TableSelect.ValueMember = "Name";

            InputsTableLayout.AutoSize = true;
            InputsTableLayout.GrowStyle = TableLayoutPanelGrowStyle.AddRows;
            InputsTableLayout.AutoSizeMode = AutoSizeMode.GrowAndShrink;

        }

        private void TableSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            var inputs = tables[TableSelect.SelectedIndex].Inputs;

            InputsTableLayout.Controls.Clear();
            InputsTableLayout.RowCount = inputs.Length;

            for (int i = 0; i < inputs.Length; i++)
            {
                var input = inputs[i];

                var label = new Label();
                label.Text = input.Label;

                Control inputBox = new TextBox();
                switch (input.Type)
                {
                    case InputType.INT:
                        inputBox = new NumericUpDown();
                        break;
                    case InputType.DECIMAL:
                        inputBox = new DecimalBox();
                        break;
                    case InputType.VARCHAR:
                        inputBox = new TextBox();
                        break;
                    case InputType.TEXT:
                        inputBox = new TextBox();
                        break;
                    case InputType.CHAR:
                        inputBox = new CheckBox();
                        break;
                }

                InputsTableLayout.Controls.Add(label, 0, i);
                InputsTableLayout.Controls.Add(inputBox, 1, i);
            }
        }

        private void PreviousButton_Click(object sender, EventArgs e)
        {

        }

        private void NextButton_Click(object sender, EventArgs e)
        {

        }

        private void InsertButton_Click(object sender, EventArgs e)
        {

        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {

        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {

        }
    }
}
