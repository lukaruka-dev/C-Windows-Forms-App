﻿namespace WindowsFormsApp2
{
    public enum InputType
    {
        INT,
        DECIMAL,
        VARCHAR,
        TEXT,
        CHAR
    }
}
