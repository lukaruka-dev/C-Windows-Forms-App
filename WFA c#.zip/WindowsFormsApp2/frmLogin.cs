﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WindowsFormsApp2
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
            

           

        }
        SqlConnection con = new SqlConnection("Data Source=RACUNAR203\\SQLEXPRESS;Initial Catalog=luka;Integrated Security=True");
        private void frmLogin_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string login = $"SELECT COUNT(*) FROM podaci WHERE  username='{txtUsername.Text}'  and sifra='{txtPassword.Text}' ";
            SqlCommand cmd = new SqlCommand(login, con);
           var a= (int)cmd.ExecuteScalar();
            con.Close();
            if (a>0)
            {
                new dashboard().Show();
                this.Hide();

            }
            else
            {
                MessageBox.Show("Netacna sifra ili username", "Neuspesno logovanje",MessageBoxButtons.OK,MessageBoxIcon.Error);
                txtUsername.Text = "";
                txtPassword.Text = "";
                txtUsername.Focus(); 
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtUsername.Focus();
        }

        private void CheckbxShowPas_CheckedChanged(object sender, EventArgs e)
        {
            if (CheckbxShowPas.Checked)
            {
                txtPassword.PasswordChar = '\0';
              
            }
            else
            {
                txtPassword.PasswordChar = '○';
              
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {
            new frmRegister().Show();
            this.Hide();


        }
    }
}
