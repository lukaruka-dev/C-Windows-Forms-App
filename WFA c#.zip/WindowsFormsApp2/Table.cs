﻿namespace WindowsFormsApp2
{
    public class Table
    {
        public string Label { get; set; }
        public string Name { get; set; }
        public Input[] Inputs;
    }
}
