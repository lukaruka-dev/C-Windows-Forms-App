﻿namespace WindowsFormsApp2
{
    public class Input
    {
        public string Label;
        public string Name;
        public InputType Type;
    }
}
